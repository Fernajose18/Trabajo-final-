package Metodos;

public class PilaListaCircular {
    private NodoProducto cima;

    public PilaListaCircular() {
        cima = null;
    }

    public boolean estaVacia() {
        return cima == null;
    }

    public void apilar(Producto producto) {
        if (estaVacia()) {
            cima = new NodoProducto(producto);
            cima.setSiguiente(cima);
        } else {
            NodoProducto nuevoNodo = new NodoProducto(producto);
            nuevoNodo.setSiguiente(cima.getSiguiente());
            cima.setSiguiente(nuevoNodo);
        }
    }

    public Producto desapilar() {
        if (estaVacia()) {
            return null; // Pila vacía, no se puede desapilar
        }

        NodoProducto nodoDesapilado = cima;
        if (cima.getSiguiente() == cima) {
            cima = null; // Único nodo en la pila
        } else {
            NodoProducto nodoAnterior = cima;
            while (nodoAnterior.getSiguiente() != cima) {
                nodoAnterior = nodoAnterior.getSiguiente();
            }
            cima = nodoAnterior;
            nodoAnterior.setSiguiente(nodoDesapilado.getSiguiente());
        }

        return nodoDesapilado.getProducto();
    }

    public Producto obtenerCima() {
        if (estaVacia()) {
            return null; // Pila vacía, no hay cima
        }
        return cima.getSiguiente().getProducto(); // Devuelve el producto en la cima
    }
}
